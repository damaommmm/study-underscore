define(function( require, exports, module){
	var sex = "男";
	return {
		sex:sex,
	}
});