define(function( require, exports, module){
	var age = "30";
	var b = require("b.js");
	console.log(b.sex);
	exports.age = age;
});